import httpx 
import asyncio
import time


async def get_urls(c, urls, result):
    for url in urls:
        res = await c.get(url)
        result.append(res)

async def setup(result):
    urls = ["http://www.google.com"]*10
    async with httpx.AsyncClient() as client:
        tasks = []
        tasks.append(get_urls(client, urls[:5], result))
        tasks.append(get_urls(client, urls[5:], result))
        r = await asyncio.gather(*tasks)

def main(*args, **kwargs):
    s = time.time()
    result = []
    asyncio.run(setup(result))
    print(time.time()-s)

if __name__ == '__main__':
    main()
