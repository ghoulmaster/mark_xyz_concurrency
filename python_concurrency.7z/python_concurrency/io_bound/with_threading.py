import requests
import time
import threading

def get_urls(urls, result):
    for url in urls:
        result.append(requests.get(url))


def main(*args, **kwargs):
    s = time.time()
    urls = ['http://www.google.com']*10
    result = []
    thread1 = threading.Thread(target=get_urls, args=(urls[:5], result))
    thread2 = threading.Thread(target=get_urls, args=(urls[5:], result))
    thread1.start()
    thread2.start()
    for thread in [thread1, thread2]:
        thread.join()
    print(time.time()-s)

if __name__ == '__main__':
    main()
