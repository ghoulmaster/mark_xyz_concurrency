import requests
import time


def get_urls(urls):
    result = []
    for url in urls:
        result.append(requests.get(url))
    return result


def main(*args, **kwargs):
    s = time.time()
    urls = ['http://www.google.com']*10
    result = get_urls(urls)
    print(time.time()-s)

if __name__ == '__main__':
    main()
