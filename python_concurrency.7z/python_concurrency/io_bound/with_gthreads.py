import requests
import gevent
import time


def get_urls(urls, result):
    for url in urls:
        result.append(requests.get(url))


def main(*args, **kwargs):
    s = time.time()
    result = []
    urls = ["http://www.google.com"]*10
    gevent.joinall([gevent.spawn(get_urls, urls[:5], result), gevent.spawn(get_urls, urls[5:], result)])
    print(time.time()-s)

if __name__ == '__main__':
    main()
