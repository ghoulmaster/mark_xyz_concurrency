import requests
import asyncio
import time


async def get_urls(urls, result):
    for url in urls:
        result.append(requests.get(url))

async def setup(result):
    urls = ["http://www.google.com"]*10
    r = await asyncio.gather(get_urls(urls[:5], result),
                             get_urls(urls[5:], result))

def main(*args, **kwargs):
    s = time.time()
    result = []
    asyncio.run(setup(result))
    print(time.time()-s)

if __name__ == '__main__':
    main()
