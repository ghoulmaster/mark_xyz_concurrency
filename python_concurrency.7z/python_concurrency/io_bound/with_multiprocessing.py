import requests
import time
import multiprocessing
def get_urls(*urls):
    result = []
    for url in urls:
        result.append(requests.get(url))
    return result

results = []
def cb(res):
    results.extend(res)

def main(*args, **kwargs):
    s = time.time()
    urls = ['http://www.google.com']*10
    pool = multiprocessing.Pool(2)
    pool.apply_async(get_urls, urls[:5], callback=cb)
    pool.apply_async(get_urls, urls[5:], callback=cb)
    pool.close()
    pool.join()
    #print(len(results))
    print(time.time()-s)

if __name__ == '__main__':
    main()
