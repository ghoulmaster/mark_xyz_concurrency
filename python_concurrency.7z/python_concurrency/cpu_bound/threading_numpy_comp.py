from numpy import zeros, array_split, linspace
import time
import threading
NT = 1
dx = 0.1
dy = 0.1
dx2 = dx*dx
dy2 = dy*dy

def calc(u):
    u[1:-1,1:-1] = ((u[2:,1:-1]+u[:-2,1:-1])*dy2 +
                    (u[1:-1,2:] + u[1:-1,:-2])*dx2) / (2*(dx2+dy2))
def intermediate(N, icl=[1]):
    for ic in icl:
        u = zeros([N, N])
        u[0] = ic
        for i in range(100):
            calc(u)

def main(*args, **kwargs):
    s = time.time()
    threads = []
    N = 30
    for icl in array_split(linspace(1, 2, 100), NT):
        t = threading.Thread(target=intermediate, args=(N, icl))
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    print(time.time() - s)
if __name__ == '__main__':
    main()
