from numpy import zeros, array_split, linspace
import time

NT = 1
dx = 0.1
dy = 0.1
dx2 = dx*dx
dy2 = dy*dy

def calc(u):
    nx, ny = u.shape
    for i in range(1,nx-1):
        for j in range(1, ny-1):
            u[i,j] = ((u[i+1, j] + u[i-1, j]) * dy2 +
                      (u[i, j+1] + u[i, j-1]) * dx2) / (2*(dx2+dy2))


def main(*args, **kwargs):
    s = time.time()
    N = 30
    for icl in array_split(linspace(1, 2, 100), NT):
        for ic in icl:
            u = zeros([N, N])
            u[0] = ic
            for i in range(100):
                calc(u)
    print(time.time() - s)
if __name__ == '__main__':
    main()
