import time
import multiprocessing

def cpu_bound_primes(lower, upper):
    result = []
    for num in range(lower, upper + 1):
        # all prime numbers are greater than 1
        if num > 1:
            for i in range(2, num):
                if (num % i) == 0:
                    break
            else:
                result.append(num)
    return result
results = []
def cb(res):
    results.extend(res)
def main(*args, **kwargs):
    s = time.time()
    pool = multiprocessing.Pool(2)
    for start, end in [(1, 20_000), (20_001, 30_000)]:
        pool.apply_async(cpu_bound_primes, args=(start, end), callback=cb)
    pool.close()
    pool.join()
    print(len(results))
    print(time.time()-s)
if __name__ == '__main__':
    main()
