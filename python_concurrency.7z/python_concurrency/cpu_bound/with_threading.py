import time
import threading

def cpu_bound_primes(lower, upper, result):
    for num in range(lower, upper + 1):
        # all prime numbers are greater than 1
        if num > 1:
            for i in range(2, num):
                if (num % i) == 0:
                    break
            else:
                result.append(num)


def main(*args, **kwargs):
    s = time.time()
    result = []
    thread1 = threading.Thread(target=cpu_bound_primes, args=(1, 20_000, result))
    thread2 = threading.Thread(target=cpu_bound_primes, args=(20_001, 30_000, result))
    thread1.start()
    thread2.start()
    for thread in [thread1, thread2]:
        thread.join()
    print(time.time()-s)
if __name__ == '__main__':
    main()
