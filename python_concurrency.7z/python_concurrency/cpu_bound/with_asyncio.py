import time
import asyncio

async def cpu_bound_primes(lower, upper, result):
    for num in range(lower, upper + 1):
        # all prime numbers are greater than 1
        if num > 1:
            for i in range(2, num):
                if (num % i) == 0:
                    break
            else:
                result.append(num)

async def setup(result):
    r = await asyncio.gather(cpu_bound_primes(1, 20_000, result),
                   cpu_bound_primes(20_001, 30_000, result))
    

def main(*args, **kwargs):
    s = time.time()
    result = []
    asyncio.run(setup(result))
    print(time.time()-s)
if __name__ == '__main__':
    main()
